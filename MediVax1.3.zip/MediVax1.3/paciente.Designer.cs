﻿namespace MediVax1._3
{
    partial class paciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dtpFechaNacimiento = new System.Windows.Forms.DateTimePicker();
            this.cmbSexo = new System.Windows.Forms.ComboBox();
            this.btnFinalizarRegistro = new System.Windows.Forms.Button();
            this.txtCurpPaciente = new System.Windows.Forms.TextBox();
            this.txtApellidosPaciente = new System.Windows.Forms.TextBox();
            this.txtNombresPaciente = new System.Windows.Forms.TextBox();
            this.btnAgregarOtroPaciente = new System.Windows.Forms.Button();
            this.btnEditarPaciente = new System.Windows.Forms.Button();
            this.btnGuardaPaciente = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.Highlight;
            this.pictureBox1.Location = new System.Drawing.Point(1, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1056, 111);
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dtpFechaNacimiento);
            this.groupBox1.Controls.Add(this.cmbSexo);
            this.groupBox1.Controls.Add(this.btnFinalizarRegistro);
            this.groupBox1.Controls.Add(this.txtCurpPaciente);
            this.groupBox1.Controls.Add(this.txtApellidosPaciente);
            this.groupBox1.Controls.Add(this.txtNombresPaciente);
            this.groupBox1.Controls.Add(this.btnAgregarOtroPaciente);
            this.groupBox1.Controls.Add(this.btnEditarPaciente);
            this.groupBox1.Controls.Add(this.btnGuardaPaciente);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(31, 118);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1015, 520);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ingresa tus datos:";
            // 
            // dtpFechaNacimiento
            // 
            this.dtpFechaNacimiento.Location = new System.Drawing.Point(147, 169);
            this.dtpFechaNacimiento.Name = "dtpFechaNacimiento";
            this.dtpFechaNacimiento.Size = new System.Drawing.Size(232, 22);
            this.dtpFechaNacimiento.TabIndex = 16;
            // 
            // cmbSexo
            // 
            this.cmbSexo.FormattingEnabled = true;
            this.cmbSexo.Items.AddRange(new object[] {
            "Femenino",
            "Masculino"});
            this.cmbSexo.Location = new System.Drawing.Point(76, 106);
            this.cmbSexo.Name = "cmbSexo";
            this.cmbSexo.Size = new System.Drawing.Size(195, 24);
            this.cmbSexo.TabIndex = 15;
            // 
            // btnFinalizarRegistro
            // 
            this.btnFinalizarRegistro.Location = new System.Drawing.Point(782, 285);
            this.btnFinalizarRegistro.Name = "btnFinalizarRegistro";
            this.btnFinalizarRegistro.Size = new System.Drawing.Size(227, 82);
            this.btnFinalizarRegistro.TabIndex = 14;
            this.btnFinalizarRegistro.Text = "Finalizar registro";
            this.btnFinalizarRegistro.UseVisualStyleBackColor = true;
            this.btnFinalizarRegistro.Click += new System.EventHandler(this.btnFinalizarRegistro_Click);
            // 
            // txtCurpPaciente
            // 
            this.txtCurpPaciente.Location = new System.Drawing.Point(76, 136);
            this.txtCurpPaciente.Name = "txtCurpPaciente";
            this.txtCurpPaciente.Size = new System.Drawing.Size(195, 22);
            this.txtCurpPaciente.TabIndex = 13;
            // 
            // txtApellidosPaciente
            // 
            this.txtApellidosPaciente.Location = new System.Drawing.Point(76, 75);
            this.txtApellidosPaciente.Name = "txtApellidosPaciente";
            this.txtApellidosPaciente.Size = new System.Drawing.Size(195, 22);
            this.txtApellidosPaciente.TabIndex = 10;
            // 
            // txtNombresPaciente
            // 
            this.txtNombresPaciente.Location = new System.Drawing.Point(76, 47);
            this.txtNombresPaciente.Name = "txtNombresPaciente";
            this.txtNombresPaciente.Size = new System.Drawing.Size(195, 22);
            this.txtNombresPaciente.TabIndex = 9;
            // 
            // btnAgregarOtroPaciente
            // 
            this.btnAgregarOtroPaciente.Location = new System.Drawing.Point(782, 197);
            this.btnAgregarOtroPaciente.Name = "btnAgregarOtroPaciente";
            this.btnAgregarOtroPaciente.Size = new System.Drawing.Size(227, 82);
            this.btnAgregarOtroPaciente.TabIndex = 8;
            this.btnAgregarOtroPaciente.Text = "Agregar otro paciente";
            this.btnAgregarOtroPaciente.UseVisualStyleBackColor = true;
            // 
            // btnEditarPaciente
            // 
            this.btnEditarPaciente.Location = new System.Drawing.Point(782, 109);
            this.btnEditarPaciente.Name = "btnEditarPaciente";
            this.btnEditarPaciente.Size = new System.Drawing.Size(227, 82);
            this.btnEditarPaciente.TabIndex = 7;
            this.btnEditarPaciente.Text = "Editar información";
            this.btnEditarPaciente.UseVisualStyleBackColor = true;
            // 
            // btnGuardaPaciente
            // 
            this.btnGuardaPaciente.Location = new System.Drawing.Point(782, 21);
            this.btnGuardaPaciente.Name = "btnGuardaPaciente";
            this.btnGuardaPaciente.Size = new System.Drawing.Size(227, 82);
            this.btnGuardaPaciente.TabIndex = 6;
            this.btnGuardaPaciente.Text = "Guardar información";
            this.btnGuardaPaciente.UseVisualStyleBackColor = true;
            this.btnGuardaPaciente.Click += new System.EventHandler(this.btnGuardaPaciente_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 204);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 16);
            this.label6.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(135, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Fecha de nacimiento:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Curp:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 114);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Sexo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 81);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Apellidos:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombres:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Highlight;
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(433, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(135, 16);
            this.label7.TabIndex = 16;
            this.label7.Text = "Registro del paciente";
            // 
            // paciente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1058, 649);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "paciente";
            this.Text = "paciente";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtCurpPaciente;
        private System.Windows.Forms.TextBox txtApellidosPaciente;
        private System.Windows.Forms.TextBox txtNombresPaciente;
        private System.Windows.Forms.Button btnAgregarOtroPaciente;
        private System.Windows.Forms.Button btnEditarPaciente;
        private System.Windows.Forms.Button btnGuardaPaciente;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFinalizarRegistro;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbSexo;
        private System.Windows.Forms.DateTimePicker dtpFechaNacimiento;
    }
}